add <-function(a,b){
   return 0
}
subtract <-function(a,b){
   return 0
}
multiplication <-function(a,b){
   return 0
}
division <-function(a,b){
   return 0
}