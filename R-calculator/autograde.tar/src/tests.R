#Write your custom test cases in this file.

#Each test case is formatted as an array of 3 elements:
#0. test case number
#1. Integer list 
#2. Output

test_cases <- list(
  list(description = "case 1", inputs = c(1, 2)),
  list(description = "case 2", inputs = c(6, 3))
)