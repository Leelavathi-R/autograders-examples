add <-function(a,b){
   return(a+b)
}
subtract <-function(a,b){
   return(a-b)
}
multiplication <-function(a,b){
   return(a*b)
}
division <-function(a,b){
   return(a/b)
}